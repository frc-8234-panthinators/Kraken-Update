package frc.robot.subsystems;

import java.util.HashMap;

import frc.robot.CoralHeights;

import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.StatusSignal;
import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.controls.Follower;
import com.ctre.phoenix6.controls.PositionVoltage;
import com.ctre.phoenix6.signals.NeutralModeValue;
import com.ctre.phoenix6.signals.InvertedValue;
import com.ctre.phoenix6.controls.VelocityVoltage;

import edu.wpi.first.units.measure.Current;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

public class ElevatorSubsystem extends SubsystemBase {
    // CAN IDs for the Neo Vortex motors
    private static final int KRAKEN_LEFT_MOTOR_CAN_ID = 15;
    private static final int KRAKEN_RIGHT_MOTOR_CAN_ID = 16;
    
    // PID constants
    private static final double kP = 0.2;
    private static final double kI = 0.0;
    private static final double kD = 0.0;
    private static final double kG = 0.0;
    private static final double MAX_VELOCITY = 1200;
    private static final double MAX_ACCELERATION = 600;

    private static HashMap<Integer, CoralHeights> blueCoralHeights = new HashMap<>();
    private static HashMap<Integer, CoralHeights> redCoralHeights = new HashMap<>();
    
    // Motor controllers
    private final TalonFX leftMotor;
    private final TalonFX rightMotor;

    // Position request object for position control
    private final PositionVoltage leftPositionRequest;
    private final PositionVoltage rightPositionRequest;

    // Current setpoint
    private double currentSetpoint = 0.0;
    
    public ElevatorSubsystem() {
        // Initialize the coral heights
        blueCoralHeights.put(17, new CoralHeights(new double[] {23, 35, 50.5, 78}, new double[] {23, 35, 50.5, 78}));
        blueCoralHeights.put(18, new CoralHeights(new double[] {23, 35, 50.5, 78}, new double[] {23, 35, 50.5, 78}));
        blueCoralHeights.put(19, new CoralHeights(new double[] {23, 35, 50.5, 78}, new double[] {23, 35, 50.5, 78}));
        blueCoralHeights.put(20, new CoralHeights(new double[] {23, 35, 50.5, 78}, new double[] {23, 35, 50.5, 78}));
        blueCoralHeights.put(21, new CoralHeights(new double[] {23, 35, 50.5, 78}, new double[] {23, 35, 50.5, 78}));
        blueCoralHeights.put(22, new CoralHeights(new double[] {23, 35, 50.5, 78}, new double[] {23, 35, 50.5, 78}));

        redCoralHeights.put(6, new CoralHeights(new double[] {23, 35, 50.5, 78}, new double[] {23, 35, 50.5, 78}));
        redCoralHeights.put(7, new CoralHeights(new double[] {23, 35, 50.5, 78}, new double[] {23, 35, 50.5, 78}));
        redCoralHeights.put(8, new CoralHeights(new double[] {23, 35, 50.5, 78}, new double[] {23, 35, 50.5, 78}));
        redCoralHeights.put(9, new CoralHeights(new double[] {23, 35, 50.5, 78}, new double[] {23, 35, 50.5, 78}));
        redCoralHeights.put(10, new CoralHeights(new double[] {23, 35, 50.5, 78}, new double[] {23, 35, 50.5, 78}));
        redCoralHeights.put(11, new CoralHeights(new double[] {23, 35, 50.5, 78}, new double[] {23, 35, 50.5, 78}));


        // Initialize motor controllers
        leftMotor = new TalonFX(KRAKEN_LEFT_MOTOR_CAN_ID);
        rightMotor = new TalonFX(KRAKEN_RIGHT_MOTOR_CAN_ID);
        
        // Configure motors
        // NOTE: One motor will need to be inverted as they are mounted opposite each other

        // Left Is Master
        TalonFXConfiguration leftConfig = new TalonFXConfiguration();
        leftConfig.MotorOutput.NeutralMode = NeutralModeValue.Brake;
        leftConfig.MotorOutput.Inverted = InvertedValue.Clockwise_Positive;

        // Configure PID for slot 0
        leftConfig.Slot0.kP = kP;
        leftConfig.Slot0.kI = kI;
        leftConfig.Slot0.kD = kD;
        leftConfig.Slot0.kS = kG; // GravityType

        // Configure motion constraints
        leftConfig.MotionMagic.MotionMagicCruiseVelocity = MAX_VELOCITY;
        leftConfig.MotionMagic.MotionMagicAcceleration = MAX_ACCELERATION;

        // Current limits
        leftConfig.CurrentLimits.SupplyCurrentLimit = 40; // Amps
        leftConfig.CurrentLimits.SupplyCurrentLimitEnable = true;

        // Create position control request
        leftPositionRequest = new PositionVoltage(0).withSlot(0);
        
        // Factory reset to ensure we're at a known state
        leftMotor.getConfigurator().setPosition(0.0);

        leftMotor.getConfigurator().apply(leftConfig);

        // Right Is Slave
        TalonFXConfiguration rightConfig = new TalonFXConfiguration();
        rightConfig.MotorOutput.NeutralMode = NeutralModeValue.Brake;

        // Configure PID for slot 0
        rightConfig.Slot0.kP = kP;
        rightConfig.Slot0.kI = kI;
        rightConfig.Slot0.kD = kD;
        rightConfig.Slot0.kS = kG; // GravityType

        // Configure motion constraints
        rightConfig.MotionMagic.MotionMagicCruiseVelocity = MAX_VELOCITY;
        rightConfig.MotionMagic.MotionMagicAcceleration = MAX_ACCELERATION;

        // Current limits
        rightConfig.CurrentLimits.SupplyCurrentLimit = 40; // Amps
        rightConfig.CurrentLimits.SupplyCurrentLimitEnable = true;

        // Create position control request
        rightPositionRequest = new PositionVoltage(0).withSlot(0);
        
        // Factory reset to ensure we're at a known state
        rightMotor.getConfigurator().setPosition(0.0);

        rightMotor.getConfigurator().apply(rightConfig);

        rightMotor.setControl(new Follower(leftMotor.getDeviceID(), true));
        

        
        // Reset encoder positions
        resetEncoders();
    }
    
    /**
     * Configure the PID controller with standard values
     */

    public double smoothElevatorPower(double startPos, double currentPos, double desiredPos, double maxPower) {
        // Calculate normalized position (progress from 0 to 1)
        double totalDistance = Math.abs(desiredPos - startPos);
        if (totalDistance < 0.001) return 0.1; // Avoid division by zero
        
        double normalizedPosition = Math.abs(currentPos - startPos) / totalDistance;
        
        // Implement trapezoidal profile using the provided function:
        // -2.5*|x-0.2|-2.5*|x-0.8|+2.5
        double scaleFactor = -2.5 * Math.abs(normalizedPosition - 0.2) 
                           - 2.5 * Math.abs(normalizedPosition - 0.8) 
                           + 2.5;
        
        // Clamp the value between 0 and 1
        scaleFactor = Math.max(0, Math.min(1, scaleFactor));
        
        return scaleFactor * maxPower;
    }
    
    /**
     * Reset encoder positions to zero
     */
    public void resetEncoders() {
        leftMotor.setPosition(0);
        rightMotor.setPosition(0);
    }
    
    /**
     * Get the current position of the elevator
     */
    public double getPosition() {
        return leftMotor.getPosition().getValueAsDouble();
    }
    
    /**
     * Set the target position for the elevator
     * @param position The target position in encoder units
     */
    /*public void setPosition(double position) {
        currentSetpoint = position;
        SmartDashboard.putNumber("PID position", position);
        leftPIDController.setReference(position, ControlType.kPosition);
        rightPIDController.setReference(-1 * position, ControlType.kPosition);
    }*/

    public void setPosition(double position, double kFF) {
        currentSetpoint = position;
        SmartDashboard.putNumber("PID position", position);
        leftMotor.setControl(new PositionVoltage(null));
        rightMotor.setControl(new PositionVoltage(null));
    }
    
    /**
     * Manual control of the elevator (for testing or manual control)
     * @param speed Speed value from -1.0 to 1.0
     */
    public void setSpeed(double speed) {
        leftMotor.set(speed);
    }
    
    /**
     * Stop the elevator
     */
    public void stop() {
        leftMotor.set(0);
    }

    public StatusSignal<Current> getLeftMotorCurrent() {
        return leftMotor.getSupplyCurrent();
    }

    public StatusSignal<Current> getRightMotorCurrent() {
        return rightMotor.getSupplyCurrent();
    }
    
    /**
     * Homes the elevator by moving it down slowly until current spike is detected
     * @param currentThreshold The current threshold in amps that indicates the elevator has hit the bottom
     * @return true if homing is complete, false if still in progress
     */
    public boolean homeElevator(double currentThreshold) {
        final double HOMING_SPEED = -0.1; // Slow downward speed
        
        // Read the current draw from the motors
        StatusSignal<Current> leftCurrent = leftMotor.getSupplyCurrent();
        StatusSignal<Current> rightCurrent = rightMotor.getSupplyCurrent();
        double totalCurrent = leftCurrent.getValueAsDouble() + rightCurrent.getValueAsDouble();
        double averageCurrent = totalCurrent / 2.0;

        // If current exceeds threshold, we've hit the bottom
        if (averageCurrent > currentThreshold) {
            // Stop the elevator
            stop();
            // Reset encoder positions to zero
            resetEncoders();
            // Homing is complete
            return true;
        } else {
            // Continue moving down slowly
            setSpeed(HOMING_SPEED);
            // Homing is still in progress
            return false;
        }
    }
    
    @Override
    public void periodic() {
        // This method will be called once per scheduler run
        // Publish current positions to SmartDashboard for debugging
        SmartDashboard.putNumber("Elevator Position", getPosition());
        SmartDashboard.putNumber("Elevator Setpoint", currentSetpoint);
        SmartDashboard.putNumber("Left Current", leftMotor.getSupplyCurrent().getValueAsDouble());
        SmartDashboard.putNumber("Right Current", rightMotor.getSupplyCurrent().getValueAsDouble());
    }

    /**
     * Get the blue coral heights map
     * @return HashMap mapping AprilTag IDs to CoralHeights objects for blue alliance
     */
    public HashMap<Integer, CoralHeights> getBlueCoralHeights() {
        return blueCoralHeights;
    }
    
    /**
     * Get the red coral heights map
     * @return HashMap mapping AprilTag IDs to CoralHeights objects for red alliance
     */
    public HashMap<Integer, CoralHeights> getRedCoralHeights() {
        return redCoralHeights;
    }
}
